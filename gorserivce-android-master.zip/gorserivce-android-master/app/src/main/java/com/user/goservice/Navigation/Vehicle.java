package com.user.goservice.Navigation;

public class Vehicle {
    public String vehicleName, vehicleReg, vid, vehicleType;

    public Vehicle(String vehicleName, String vehicleReg, String vid, String vehicleType) {
        this.vehicleName = vehicleName;
        this.vehicleReg = vehicleReg;
        this.vid = vid;
        this.vehicleType = vehicleType;

    }
}
