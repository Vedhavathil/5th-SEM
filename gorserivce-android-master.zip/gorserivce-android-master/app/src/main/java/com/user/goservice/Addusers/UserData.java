package com.user.goservice.Addusers;

public class UserData {
    public String username, email, phoneNumber;

    public UserData(String username, String email, String phoneNumber) {
        this.username = username;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public UserData() {
    }
}
