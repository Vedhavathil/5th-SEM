package com.user.goservice.Services;

public class Service {
    public String serviceName;
    public int price;

    public  Service(String serviceName, int price) {
        this.serviceName = serviceName;
        this.price = price;
    }
}