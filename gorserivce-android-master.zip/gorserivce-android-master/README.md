# gorserivce-android
An Android application which illustrates booking vehicle service. For backend this application uses MYSQL database and Firebase real time database.
